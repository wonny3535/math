---
layout: article
title: Copyright | Yeonmu Math Club
date: 2021-09-01
mathjax: true
lang: ko
permalink: /copyright/
---

# 저작권 관련 공지
<br>
본 웹사이트는 수원 연무중학교 학생자율동아리, "창의로운 수학생활" 동아리의 활동을 정리한 웹사이트입니다.<br>웹사이트 디자인은 <a href="https://creativecommons.org/licenses/by/3.0/" target="_blank">CCA 3.0 license</a>로 배포된 <a href="https://github.com/andrewbanchich/phantom-jekyll-theme" target="_blank">Phantom</a>을 일부 사용하였습니다.<br>웹사이트의 문제는 대부분 알려진 문제를 사용하였으며, 풀이는 동아리원들과 함께 푼 방식을 참고하여 작성하였습니다. 보고서는 동아리원들이 직접 작성한 것을 거의 그대로 사용하였으며, 그림은 따로 명시하지 않은 경우 모두 직접 그린 것이거나 Public domain 그림을 사용한 것입니다.<br>
본 웹사이트는 비영리 목적으로 운영되고 있습니다.<br>
본 웹사이트의 내용의 전부 또는 일부는 학교 등 비영리 공교육 기관에서 교육용으로 사용하실 수 있습니다.
